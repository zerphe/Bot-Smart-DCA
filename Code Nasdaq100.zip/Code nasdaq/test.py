import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def simulateur_match_historique():
    print("🚀 Simulation : DCA Classique vs Smart DCA (2020 - 2025)")
    
    # 1. RÉCUPÉRATION DES DONNÉES
    # On télécharge ^NDX (Nasdaq) et ^VIX
    df = yf.download(["^NDX", "^VIX"], start="2019-06-01", end="2025-12-31", progress=False)
    
    # Gestion du formatage yfinance
    if isinstance(df.columns, pd.MultiIndex):
        prices = df['Close']['^NDX']
        vix = df['Close']['^VIX']
    else:
        prices = df['Close']
        vix = df['^VIX'] # dépend de la version
        
    data = pd.DataFrame({'Close': prices, 'VIX': vix}).dropna()

    # 2. INDICATEURS TECHNIQUES
    data['ATH'] = data['Close'].cummax()
    data['Drawdown'] = ((data['Close'] - data['ATH']) / data['ATH']) * 100
    data['MA20'] = data['Close'].rolling(window=20).mean()
    data['STD20'] = data['Close'].rolling(window=20).std()
    data['Z-Score'] = (data['Close'] - data['MA20']) / data['STD20']
    
    # On cadre sur la période demandée
    data = data.loc['2020-01-01':'2025-12-31']

    # 3. VARIABLES DE SIMULATION
    budget_base = 300
    
    # Classique
    cash_classique = 0
    parts_classique = 0
    
    # Smart
    cash_smart = 0
    parts_smart = 0
    
    history = []

    # Simulation d'achat mensuel
    for i in range(0, len(data), 21):
        row = data.iloc[i]
        prix = row['Close']
        vix_val = row['VIX']
        dd = row['Drawdown']
        z = row['Z-Score']
        
        # --- CALCUL DU MONTANT SMART (Ton Algorithme) ---
        score_dd = (abs(dd) / 30.0) ** 2.0
        score_boll = 0.15 * (abs(z) - 1) ** 1.5 if z < -1.0 else 0
        score_vix = (vix_val - 20) / 40.0 if vix_val > 20 else 0
        
        alpha = 1.0 + score_dd + score_boll + score_vix
        if alpha > 3.5: alpha = 3.5 
        
        montant_smart = budget_base * alpha
        
        # --- EXÉCUTION ---
        # Classique
        cash_classique += budget_base
        parts_classique += budget_base / prix
        
        # Smart
        cash_smart += montant_smart
        parts_smart += montant_smart / prix
        
        history.append({
            'Date': data.index[i],
            'Portefeuille_Classique': parts_classique * prix,
            'Portefeuille_Smart': parts_smart * prix,
            'Investi_Classique': cash_classique,
            'Investi_Smart': cash_smart,
            'Alpha': alpha
        })

    # 4. RÉSULTATS
    res = pd.DataFrame(history).set_index('Date')
    
    roi_classique = ((res['Portefeuille_Classique'].iloc[-1] - cash_classique) / cash_classique) * 100
    roi_smart = ((res['Portefeuille_Smart'].iloc[-1] - cash_smart) / cash_smart) * 100

    print(f"\n--- BILAN FINAL (01/2020 - 12/2025) ---")
    print(f"CLASSIQUE : Investi {cash_classique:,.0f}€ | Valeur : {res['Portefeuille_Classique'].iloc[-1]:,.0f}€ | ROI : {roi_classique:.2f}%")
    print(f"SMART     : Investi {cash_smart:,.0f}€ | Valeur : {res['Portefeuille_Smart'].iloc[-1]:,.0f}€ | ROI : {roi_smart:.2f}%")
    print(f"DIFFÉRENCE DE PERFORMANCE (ROI) : {roi_smart - roi_classique:+.2f}%")

    # 5. GRAPHIQUE À DOUBLE AXE
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10), sharex=True, gridspec_kw={'height_ratios': [3, 1]})

    # Top : Valeur du portefeuille
    ax1.plot(res.index, res['Portefeuille_Classique'], label='DCA Classique', color='gray', linestyle='--')
    ax1.plot(res.index, res['Portefeuille_Smart'], label='SMART DCA (Ton Bot)', color='#1f77b4', linewidth=2)
    ax1.fill_between(res.index, res['Portefeuille_Classique'], res['Portefeuille_Smart'], color='blue', alpha=0.1)
    ax1.set_title("MATCH ULTIME : 6 ANS DE NASDAQ (2020-2025)", fontsize=14, fontweight='bold')
    ax1.set_ylabel("Valeur (€)")
    ax1.legend()
    ax1.grid(True, alpha=0.2)

    # Bottom : Coefficient Alpha (Quand le bot a chargé la mule)
    ax2.fill_between(res.index, 1, res['Alpha'], color='orange', alpha=0.3, label='Coefficient de renforcement (Alpha)')
    ax2.axhline(y=1, color='black', linestyle='-', alpha=0.5)
    ax2.set_ylabel("Multiplicateur")
    ax2.set_ylim(0.8, 3.7)
    ax2.legend()
    ax2.grid(True, alpha=0.2)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    simulateur_match_historique()